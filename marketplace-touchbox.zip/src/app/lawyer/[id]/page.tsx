import { notFound } from 'next/navigation';
import { mockLawyers } from '@/data/lawyers';
import { LawyerProfileClient } from '@/components/LawyerProfileClient';

// Generate static params for all lawyers
export function generateStaticParams() {
  return mockLawyers.map((lawyer) => ({
    id: lawyer.id,
  }));
}

interface LawyerProfileProps {
  params: Promise<{
    id: string;
  }>;
}

export default async function LawyerProfile({ params }: LawyerProfileProps) {
  const { id } = await params;
  const lawyer = mockLawyers.find(l => l.id === id);

  if (!lawyer) {
    notFound();
  }

  return <LawyerProfileClient lawyer={lawyer} />;
}
