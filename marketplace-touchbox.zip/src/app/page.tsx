'use client';

import { useState } from 'react';
import { SearchFiltersComponent } from '@/components/SearchFilters';
import { LawyerCard } from '@/components/LawyerCard';
import { mockLawyers, searchLawyers } from '@/data/lawyers';
import type { SearchFilters } from '@/types/lawyer';
import { Scale } from 'lucide-react';

export default function Home() {
  const [currentFilters, setCurrentFilters] = useState<SearchFilters>({
    query: '',
    region: '',
    city: '',
    specialization: ''
  });

  const filteredLawyers = searchLawyers(
    mockLawyers,
    currentFilters.query,
    currentFilters.region,
    currentFilters.city,
    currentFilters.specialization
  );

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-600 rounded-lg">
              <Scale className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Маркетплейс Адвокатів України
              </h1>
              <p className="text-gray-600">
                Знайдіть кваліфікованого адвоката у вашому регіоні
              </p>
            </div>
          </div>

          {/* Search and Filters */}
          <SearchFiltersComponent
            onFiltersChange={setCurrentFilters}
            resultsCount={filteredLawyers.length}
          />
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {filteredLawyers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLawyers.map((lawyer) => (
              <LawyerCard key={lawyer.id} lawyer={lawyer} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <Scale className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Адвокатів не знайдено
            </h3>
            <p className="text-gray-600 mb-4">
              Спробуйте змінити критерії пошуку або очистити фільтри
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-gray-600">
            <p className="mb-2">
              © 2025 Маркетплейс Адвокатів України. Всі права захищені.
            </p>
            <p className="text-sm">
              Професійні юридичні послуги по всій Україні
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}
