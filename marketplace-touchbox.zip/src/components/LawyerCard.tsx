'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MapPin, Star, Eye, EyeOff, Phone, Mail, Globe } from 'lucide-react';
import type { Lawyer } from '@/types/lawyer';

interface LawyerCardProps {
  lawyer: Lawyer;
}

export function LawyerCard({ lawyer }: LawyerCardProps) {
  const [showContacts, setShowContacts] = useState(lawyer.isContactVisible);

  const getInitials = (fullName: string) => {
    return fullName
      .split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase();
  };

  const toggleContacts = () => {
    setShowContacts(!showContacts);
  };

  return (
    <Card className="h-full hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="text-lg font-semibold">
              {getInitials(lawyer.fullName)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <CardTitle className="text-xl mb-1">{lawyer.fullName}</CardTitle>
            <CardDescription className="flex items-center gap-1 mb-2">
              <MapPin className="h-4 w-4" />
              {lawyer.city}, {lawyer.region}
            </CardDescription>
            <div className="flex items-center gap-2">
              {lawyer.rating && (
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{lawyer.rating}</span>
                  <span className="text-sm text-muted-foreground">
                    ({lawyer.reviewsCount} відгуків)
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div>
          <p className="text-sm text-muted-foreground mb-2">Спеціалізації:</p>
          <div className="flex flex-wrap gap-2">
            {lawyer.specializations.slice(0, 3).map((spec) => (
              <Badge key={spec} variant="secondary" className="text-xs">
                {spec}
              </Badge>
            ))}
            {lawyer.specializations.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{lawyer.specializations.length - 3} більше
              </Badge>
            )}
          </div>
        </div>

        <div>
          <p className="text-sm text-muted-foreground">Досвід: {lawyer.experience} років</p>
        </div>

        {lawyer.description && (
          <div>
            <p className="text-sm line-clamp-3">{lawyer.description}</p>
          </div>
        )}

        <div>
          <p className="text-sm text-muted-foreground mb-1">Адреса:</p>
          <p className="text-sm">{lawyer.address}</p>
        </div>

        {/* Contact Information */}
        <div className="border-t pt-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium">Контактна інформація</p>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleContacts}
              className="flex items-center gap-2"
            >
              {showContacts ? (
                <>
                  <EyeOff className="h-4 w-4" />
                  Приховати
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4" />
                  Показати
                </>
              )}
            </Button>
          </div>

          {showContacts ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <a href={`tel:${lawyer.contactInfo.phone}`} className="text-sm hover:underline">
                  {lawyer.contactInfo.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <a href={`mailto:${lawyer.contactInfo.email}`} className="text-sm hover:underline">
                  {lawyer.contactInfo.email}
                </a>
              </div>
              {lawyer.contactInfo.website && (
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-muted-foreground" />
                  <a
                    href={`https://${lawyer.contactInfo.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm hover:underline"
                  >
                    {lawyer.contactInfo.website}
                  </a>
                </div>
              )}
            </div>
          ) : (
            <div className="text-sm text-muted-foreground italic">
              Контакти приховані. Натисніть "Показати" для перегляду.
            </div>
          )}
        </div>

        <div className="pt-2">
          <Button
            className="w-full"
            onClick={() => {
              window.location.href = `/lawyer/${lawyer.id}`;
            }}
          >
            Переглянути профіль
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
