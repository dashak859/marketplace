'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, MapPin, Star, Phone, Mail, Globe, GraduationCap, Languages, Calendar, Eye, EyeOff } from 'lucide-react';
import { Lawyer } from '@/types/lawyer';

interface LawyerProfileClientProps {
  lawyer: Lawyer;
}

export function LawyerProfileClient({ lawyer }: LawyerProfileClientProps) {
  const router = useRouter();
  const [showContacts, setShowContacts] = useState(false);

  const getInitials = (fullName: string) => {
    return fullName
      .split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase();
  };

  const toggleContacts = () => {
    setShowContacts(!showContacts);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="outline"
            onClick={() => router.push('/')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Повернутися до пошуку
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Profile Card */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-start gap-6">
                  <Avatar className="h-24 w-24">
                    <AvatarFallback className="text-2xl font-semibold">
                      {getInitials(lawyer.fullName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-3xl mb-2">{lawyer.fullName}</CardTitle>
                    <CardDescription className="flex items-center gap-2 mb-3 text-lg">
                      <MapPin className="h-5 w-5" />
                      {lawyer.city}, {lawyer.region}
                    </CardDescription>
                    {lawyer.rating && (
                      <div className="flex items-center gap-2 mb-4">
                        <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                        <span className="text-lg font-medium">{lawyer.rating}</span>
                        <span className="text-muted-foreground">
                          ({lawyer.reviewsCount} відгуків)
                        </span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2">
                      {lawyer.specializations.map((spec) => (
                        <Badge key={spec} variant="secondary">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Description */}
                {lawyer.description && (
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Про адвоката</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {lawyer.description}
                    </p>
                  </div>
                )}

                {/* Education */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <GraduationCap className="h-5 w-5" />
                    Освіта
                  </h3>
                  <ul className="space-y-2">
                    {lawyer.education.map((edu) => (
                      <li key={edu} className="text-muted-foreground">
                        • {edu}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Languages */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Languages className="h-5 w-5" />
                    Мови
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {lawyer.languages.map((lang) => (
                      <Badge key={lang} variant="outline">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Experience */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Досвід роботи
                  </h3>
                  <p className="text-muted-foreground">
                    {lawyer.experience} років професійної практики
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Контактна інформація
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleContacts}
                    className="flex items-center gap-2"
                  >
                    {showContacts ? (
                      <>
                        <EyeOff className="h-4 w-4" />
                        Приховати
                      </>
                    ) : (
                      <>
                        <Eye className="h-4 w-4" />
                        Показати
                      </>
                    )}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {showContacts ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Телефон</p>
                        <a href={`tel:${lawyer.contactInfo.phone}`} className="text-blue-600 hover:underline">
                          {lawyer.contactInfo.phone}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Email</p>
                        <a href={`mailto:${lawyer.contactInfo.email}`} className="text-blue-600 hover:underline">
                          {lawyer.contactInfo.email}
                        </a>
                      </div>
                    </div>
                    {lawyer.contactInfo.website && (
                      <div className="flex items-center gap-3">
                        <Globe className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">Веб-сайт</p>
                          <a
                            href={`https://${lawyer.contactInfo.website}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            {lawyer.contactInfo.website}
                          </a>
                        </div>
                      </div>
                    )}
                    <div className="pt-4 border-t">
                      <Button className="w-full">
                        Зв'язатися з адвокатом
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      Контактні дані приховані для захисту приватності
                    </p>
                    <Button onClick={toggleContacts} variant="outline">
                      Показати контакти
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Address */}
            <Card>
              <CardHeader>
                <CardTitle>Адреса</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="font-medium">{lawyer.city}</p>
                    <p className="text-muted-foreground">{lawyer.address}</p>
                    <p className="text-sm text-muted-foreground">{lawyer.region}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
