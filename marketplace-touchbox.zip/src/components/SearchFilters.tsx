'use client';

import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter, X } from 'lucide-react';
import type { SearchFilters } from '@/types/lawyer';
import { ukrainianRegions, specializations } from '@/data/regions';

interface SearchFiltersProps {
  onFiltersChange: (filters: SearchFilters) => void;
  resultsCount?: number;
}

export function SearchFiltersComponent({ onFiltersChange, resultsCount }: SearchFiltersProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    region: '',
    city: '',
    specialization: ''
  });

  const [availableCities, setAvailableCities] = useState<string[]>([]);

  // Update available cities when region changes
  useEffect(() => {
    if (filters.region) {
      const selectedRegion = ukrainianRegions.find(region => region.name === filters.region);
      setAvailableCities(selectedRegion?.cities || []);

      // Reset city if it's not available in the new region
      if (filters.city && selectedRegion && !selectedRegion.cities.includes(filters.city)) {
        setFilters(prev => ({ ...prev, city: '' }));
      }
    } else {
      setAvailableCities([]);
      setFilters(prev => ({ ...prev, city: '' }));
    }
  }, [filters.region, filters.city]);

  // Notify parent component when filters change
  useEffect(() => {
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const updateFilter = (key: keyof SearchFilters, value: string) => {
    // Convert "all-" values to empty strings for filtering logic
    const filterValue = value.startsWith('all-') ? '' : value;
    setFilters(prev => ({ ...prev, [key]: filterValue }));
  };

  const clearAllFilters = () => {
    setFilters({
      query: '',
      region: '',
      city: '',
      specialization: ''
    });
  };

  const hasActiveFilters = filters.query || filters.region || filters.city || filters.specialization;

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Пошук за ПІБ адвоката..."
          value={filters.query}
          onChange={(e) => updateFilter('query', e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Region Filter */}
        <Select
          value={filters.region || 'all-regions'}
          onValueChange={(value) => updateFilter('region', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Оберіть область" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-regions">Всі області</SelectItem>
            {ukrainianRegions.map((region) => (
              <SelectItem key={region.name} value={region.name}>
                {region.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* City Filter */}
        <Select
          value={filters.city || 'all-cities'}
          onValueChange={(value) => updateFilter('city', value)}
          disabled={!filters.region}
        >
          <SelectTrigger>
            <SelectValue placeholder="Оберіть місто" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-cities">Всі міста</SelectItem>
            {availableCities.map((city) => (
              <SelectItem key={city} value={city}>
                {city}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Specialization Filter */}
        <Select
          value={filters.specialization || 'all-specializations'}
          onValueChange={(value) => updateFilter('specialization', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Спеціалізація" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-specializations">Всі спеціалізації</SelectItem>
            {specializations.map((spec) => (
              <SelectItem key={spec} value={spec}>
                {spec}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Clear Filters Button */}
        <Button
          variant="outline"
          onClick={clearAllFilters}
          disabled={!hasActiveFilters}
          className="flex items-center gap-2"
        >
          <X className="h-4 w-4" />
          Очистити
        </Button>
      </div>

      {/* Results Count */}
      {resultsCount !== undefined && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Filter className="h-4 w-4" />
          <span>
            Знайдено {resultsCount} {resultsCount === 1 ? 'адвокат' : resultsCount < 5 ? 'адвокати' : 'адвокатів'}
          </span>
          {hasActiveFilters && (
            <span className="text-blue-600">
              за заданими критеріями
            </span>
          )}
        </div>
      )}
    </div>
  );
}
