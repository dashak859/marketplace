export interface Lawyer {
  id: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  fullName: string;
  region: string;
  city: string;
  address: string;
  specializations: string[];
  experience: number; // years
  education: string[];
  languages: string[];
  rating?: number;
  reviewsCount?: number;
  profileImage?: string;
  description?: string;
  contactInfo: {
    phone: string;
    email: string;
    website?: string;
  };
  isContactVisible: boolean;
}

export interface Region {
  name: string;
  cities: string[];
}

export interface SearchFilters {
  query: string;
  region: string;
  city: string;
  specialization: string;
}
