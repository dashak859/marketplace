import type { Lawyer } from '@/types/lawyer';

export const mockLawyers: Lawyer[] = [
  {
    id: '1',
    firstName: 'Олександр',
    lastName: 'Петренко',
    middleName: 'Іванович',
    fullName: 'Петренко Олександр Іванович',
    region: 'Київська область',
    city: 'Київ',
    address: 'вул. Хрещатик, 25, оф. 401',
    specializations: ['Цивільне право', 'Сімейне право', 'Господарське право'],
    experience: 12,
    education: ['Київський національний університет імені Тараса Шевченка', 'Магістр права (2011)'],
    languages: ['Українська', 'Англійська', 'Російська'],
    rating: 4.8,
    reviewsCount: 127,
    description: 'Досвідчений адвокат з широкою практикою у цивільних та господарських справах. Спеціалізуюсь на захисті прав підприємців та вирішенні сімейних конфліктів.',
    contactInfo: {
      phone: '+380 67 123 45 67',
      email: 'petrenko.lawyer@gmail.com',
      website: 'www.petrenko-law.com.ua'
    },
    isContactVisible: false
  },
  {
    id: '2',
    firstName: 'Марія',
    lastName: 'Коваленко',
    middleName: 'Сергіївна',
    fullName: 'Коваленко Марія Сергіївна',
    region: 'Львівська область',
    city: 'Львів',
    address: 'пр. Свободи, 17, кв. 12',
    specializations: ['Кримінальне право', 'Адміністративне право'],
    experience: 8,
    education: ['Львівський національний університет імені Івана Франка', 'Бакалавр права (2013)', 'Магістр права (2015)'],
    languages: ['Українська', 'Польська', 'Англійська'],
    rating: 4.6,
    reviewsCount: 89,
    description: 'Спеціаліст з кримінального права. Успішно веду справи різної складності, забезпечую якісний захист у суді.',
    contactInfo: {
      phone: '+380 50 234 56 78',
      email: 'kovalenko.maria@law.ua'
    },
    isContactVisible: false
  },
  {
    id: '3',
    firstName: 'Володимир',
    lastName: 'Іваненко',
    middleName: 'Олексійович',
    fullName: 'Іваненко Володимир Олексійович',
    region: 'Харківська область',
    city: 'Харків',
    address: 'вул. Сумська, 45, 3-й поверх',
    specializations: ['IT право', 'Інтелектуальна власність', 'Господарське право'],
    experience: 6,
    education: ['Національний юридичний університет імені Ярослава Мудрого', 'Магістр права (2017)'],
    languages: ['Українська', 'Англійська'],
    rating: 4.9,
    reviewsCount: 156,
    description: 'Молодий та амбітний адвокат, що спеціалізується на IT-праві та захисті інтелектуальної власності. Працюю з стартапами та IT-компаніями.',
    contactInfo: {
      phone: '+380 95 345 67 89',
      email: 'ivanenko.it@lawyer.com',
      website: 'it-lawyer.kharkiv.ua'
    },
    isContactVisible: false
  },
  {
    id: '4',
    firstName: 'Наталія',
    lastName: 'Мельник',
    middleName: 'Василівна',
    fullName: 'Мельник Наталія Василівна',
    region: 'Дніпропетровська область',
    city: 'Дніпро',
    address: 'пр. Дмитра Яворницького, 91',
    specializations: ['Трудове право', 'Медичне право', 'Захист прав споживачів'],
    experience: 15,
    education: ['Дніпровський національний університет', 'Магістр права (2008)', 'Аспірантура (2011)'],
    languages: ['Українська', 'Німецька'],
    rating: 4.7,
    reviewsCount: 203,
    description: 'Досвідчений фахівець з трудового та медичного права. Допомагаю працівникам захистити свої права, а також надаю консультації медичним закладам.',
    contactInfo: {
      phone: '+380 56 456 78 90',
      email: 'melnyk.natalia@legal.dp.ua'
    },
    isContactVisible: false
  },
  {
    id: '5',
    firstName: 'Андрій',
    lastName: 'Бондаренко',
    middleName: 'Миколайович',
    fullName: 'Бондаренко Андрій Миколайович',
    region: 'Одеська область',
    city: 'Одеса',
    address: 'вул. Дерибасівська, 13, оф. 205',
    specializations: ['Міжнародне право', 'Банківське право', 'Податкове право'],
    experience: 20,
    education: ['Одеський національний університет імені І.І. Мечникова', 'Магістр права (2003)', 'Кандидат юридичних наук (2007)'],
    languages: ['Українська', 'Англійська', 'Французька', 'Російська'],
    rating: 4.9,
    reviewsCount: 312,
    description: 'Провідний експерт з міжнародного та банківського права. Маю значний досвід роботи з міжнародними компаніями та складними фінансовими операціями.',
    contactInfo: {
      phone: '+380 48 567 89 01',
      email: 'bondarenko@international-law.od.ua',
      website: 'www.bondarenko-law.com'
    },
    isContactVisible: false
  },
  {
    id: '6',
    firstName: 'Ірина',
    lastName: 'Савченко',
    middleName: 'Петрівна',
    fullName: 'Савченко Ірина Петрівна',
    region: 'Полтавська область',
    city: 'Полтава',
    address: 'вул. Соборності, 28А',
    specializations: ['Земельне право', 'Будівельне право', 'Цивільне право'],
    experience: 10,
    education: ['Полтавський юридичний інститут', 'Магістр права (2013)'],
    languages: ['Українська', 'Англійська'],
    rating: 4.5,
    reviewsCount: 67,
    description: 'Спеціалізуюсь на земельних відносинах та будівельному праві. Допомагаю клієнтам вирішувати питання з нерухомістю та земельними ділянками.',
    contactInfo: {
      phone: '+380 532 678 90 12',
      email: 'savchenko.land@lawyer.poltava.ua'
    },
    isContactVisible: false
  },
  {
    id: '7',
    firstName: 'Сергій',
    lastName: 'Гриценко',
    middleName: 'Вікторович',
    fullName: 'Гриценко Сергій Вікторович',
    region: 'Вінницька область',
    city: 'Вінниця',
    address: 'вул. Театральна, 15, 2-й поверх',
    specializations: ['Кримінальне право', 'Адміністративне право', 'Цивільне право'],
    experience: 14,
    education: ['Вінницький національний аграрний університет', 'Магістр права (2009)'],
    languages: ['Українська', 'Російська'],
    rating: 4.6,
    reviewsCount: 145,
    description: 'Універсальний адвокат з великим досвідом у різних галузях права. Готовий взятися за справи будь-якої складності.',
    contactInfo: {
      phone: '+380 432 789 01 23',
      email: 'gritsenko.law@vn.ua'
    },
    isContactVisible: false
  },
  {
    id: '8',
    firstName: 'Оксана',
    lastName: 'Левченко',
    middleName: 'Анатоліївна',
    fullName: 'Левченко Оксана Анатоліївна',
    region: 'Запорізька область',
    city: 'Запоріжжя',
    address: 'пр. Соборний, 112, оф. 15',
    specializations: ['Сімейне право', 'Спадкове право', 'Цивільне право'],
    experience: 9,
    education: ['Запорізький національний університет', 'Магістр права (2014)'],
    languages: ['Українська', 'Англійська'],
    rating: 4.8,
    reviewsCount: 98,
    description: 'Делікатно вирішую сімейні конфлікти та питання спадкового права. Підходжу до кожної справи з розумінням та професіоналізмом.',
    contactInfo: {
      phone: '+380 61 890 12 34',
      email: 'levchenko.family@zp.lawyer'
    },
    isContactVisible: false
  }
];

// Функція для пошуку адвокатів
export function searchLawyers(
  lawyers: Lawyer[],
  query: string,
  region: string,
  city: string,
  specialization: string
): Lawyer[] {
  return lawyers.filter(lawyer => {
    const matchesQuery = query === '' ||
      lawyer.fullName.toLowerCase().includes(query.toLowerCase()) ||
      lawyer.firstName.toLowerCase().includes(query.toLowerCase()) ||
      lawyer.lastName.toLowerCase().includes(query.toLowerCase());

    const matchesRegion = region === '' || lawyer.region === region;
    const matchesCity = city === '' || lawyer.city === city;
    const matchesSpecialization = specialization === '' ||
      lawyer.specializations.includes(specialization);

    return matchesQuery && matchesRegion && matchesCity && matchesSpecialization;
  });
}
